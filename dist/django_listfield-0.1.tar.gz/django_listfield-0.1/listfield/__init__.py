from .fields import CharListFormField, CharListField

default_app_config = 'listfield.apps.ListfieldConfig'