from django.apps import AppConfig


class ListfieldConfig(AppConfig):
    name = 'listfield'