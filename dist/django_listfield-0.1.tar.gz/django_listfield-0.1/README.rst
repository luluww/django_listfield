=====
Django_listfield
=====

django_listfield is a Django app to provide list field for model sor forms. 


Quick start
-----------

Add "django_listfield" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...
        'django_listfield',
    ]

